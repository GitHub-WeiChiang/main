==============
Version 4.5.17
==============

Version 4.5.17 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.5.17

Bugs Fixed
----------

* Addition in ``mod_wsgi-express`` of ``--allow-override`` option in 4.5.16
  caused ``--url-alias`` option to break.
